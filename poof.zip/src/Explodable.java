public interface Explodable
{
}
